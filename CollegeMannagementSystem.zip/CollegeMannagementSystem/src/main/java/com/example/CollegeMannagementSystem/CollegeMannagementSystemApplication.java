package com.example.CollegeMannagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeMannagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeMannagementSystemApplication.class, args);
	}

}
